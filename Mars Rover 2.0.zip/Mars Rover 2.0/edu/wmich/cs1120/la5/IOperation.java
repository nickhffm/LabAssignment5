package edu.wmich.cs1120.la5;

/**
 * 
 * @author Nick Huffman
 *
 */
public interface IOperation {
	public Integer perform(IExpression left, IExpression right);
}
