package edu.wmich.cs1120.la5;

/**
 * 
 * @author Nick Huffman
 *
 */
public interface IExpression {
	
	public Integer getValue();
}
